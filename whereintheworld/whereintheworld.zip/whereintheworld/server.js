// Express initialization
var express = require('express');
var bodyParser = require('body-parser');
var validator = require('validator'); // See documentation at https://github.com/chriso/validator.js
var app = express();
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));

// Mongo initialization, setting up a connection to a MongoDB  (on Heroku or localhost)
var mongoUri = process.env.MONGOLAB_URI || process.env.MONGOHQ_URL || 'mongodb://localhost/whereintheworld';
var mongo = require('mongodb');
var db = mongo.Db.connect(mongoUri, function (error, databaseConnection) {
  db = databaseConnection;
});

app.post('/sendLocation', function (request, response) {
	// enable Cross-Origin Resource Sharing
	response.header("Access-Control-Allow-Origin", "*");
	response.header("Access-Control-Allow-Headers", "X-Requested-With");
	
	// send back JSON
	response.set('Content-Type', 'application/json');

	// get parameters from request
	var login = request.body.login;
	var lat = request.body.lat;
	var lng = request.body.lng;
	var time = new Date().getTime();

	// if valid parameters (login,lat,lng)
	if (login != undefined && lat != undefined && lng != undefined) {
		loc = db.collection('locations', function (err, collection) {
			// entry to insert
			var entry = {'login': login, 'lat': parseFloat(lat), 'lng': parseFloat(lng), 'created_at': time};

		  	var id = collection.insert(entry, function(err, saved) {
				if (!err) {
					collection.find().toArray(function(er, cursor) {
						if (!err) {
							var return_array = {'characters': [], 'students':[]};

							// push last 100 locations
							for (var count = 0; count < 100; count++) {
								// make sure within bounds of DB data
								if (count < cursor.length) {
									return_array['students'].push(cursor[count]);
								}
							}

							// sort array based on time (see readme for algorithm source)
							return_array['students'].sort(function(a,b) {
								var x = a['created_at'];
								var y = b['created_at'];
								return ((x < y) ? 1 : ((x > y) ? -1 : 0));
							});

							// send array
							response.send(JSON.stringify(return_array));
						}
					});
				}
				else {
					response.send({"status":"Error: data did not go through"});
				}
			});
		});
	// else, send error message (message from ChickenOfTheSea)
	} else {
		response.send({"status":"Error: data did not go through"});
	}
});

app.get('/locations.json', function (request, response) {
	// enable Cross-Origin Resource Sharing
	response.header("Access-Control-Allow-Origin", "*");
	response.header("Access-Control-Allow-Headers", "X-Requested-With");

	// send back JSON
	response.set('Content-Type', 'application/json');
	var login = request.body.login;

	// if user included login
	if (login != undefined) {
		loc = db.collection('locations', function (err, collection) {
			collection.find().toArray(function(er, cursor) {
				if (!err) {
					var return_array = [];

					// return all locations from specified login
					for (var count = 0; count < cursor.length; count++) {
						if (cursor[count]['login'] == login) {
							return_array.push(cursor[count]);
						}
					}

					// sort array by time (see readme for source)
					return_array.sort(function(a,b) {
						var x = a['created_at'];
						var y = b['created_at'];
						return ((x < y) ? 1 : ((x > y) ? -1 : 0));
					});

					response.send(JSON.stringify(return_array));
				}
			});
		});
	// no login specified, send blank array
	} else {
		response.send([]);
	}
});

app.get('/', function (request, response) {
	// send back HTML
	response.set('Content-Type', 'text/html');
	loc = db.collection('locations', function (err, collection) {
		collection.find().toArray(function (er, cursor) {
			if (!er) {
				// initialize data_obj and HTML
				var data_obj = {'characters': [], 'students':[]};
				var css_out = 'body {text-align: center; font-family: "Comic Sans MS";} .time {color: #77bdee;}'
				var html_out = '<html><head><title>Where in the World?</title></head><style>'+css_out+'</style><body><h1>Where in the World...</h1>'
				
				// add each student to data_obj
				for (var i = 0; i < cursor.length; i++) {
					data_obj['students'].push(cursor[i]);
				}

				// sort array (see readme)
				data_obj['students'].sort(function(a,b) {
					var x = a['created_at'];
					var y = b['created_at'];
					return ((x < y) ? 1 : ((x > y) ? -1 : 0));
				});

				// for each student, append new line of data to HTML
				for (var i=0; i < data_obj['students'].length; i++) {
					var entry = data_obj['students'][i];
					html_out += '<p><span class="time">' + entry['created_at'];
					html_out += 'ms:</span> ' + entry['login'];
					html_out += ' @ ' + entry['lat'] + ', ' + entry['lng'];
					html_out += '</p>';
				}

				html_out += '</body></html>';
				response.send(html_out);
			}
		});
	});
});

app.get('/redline.json', function (request, response) {
	// enable Cross-Origin Resource Sharing
	response.header("Access-Control-Allow-Origin", "*");
	response.header("Access-Control-Allow-Headers", "X-Requested-With");

	// send back JSON
	response.set('Content-Type', 'application/json');

	// verify and set HTTP options
	var http = require('http');
	var options = {
		host: 'developer.mbta.com',
		port: 80,
		path: '/lib/rthr/red.json'
	};

	http.get(options, function(res) {
		var data = '';

		// add each chunk to data
		res.on("data", function(chunk) {
			data += chunk;
		});

		// return all of data when done
		res.on("end", function() {
			response.send(data);
		});
	}).on('error', function(err) {
		response.send("Got error: " + err.message);
	});
});

app.listen(process.env.PORT || 3000);